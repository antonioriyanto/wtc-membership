import type { Request, Response, NextFunction } from 'express';

export interface AuthenticatedRequest extends Request {
  user?: Record<string, any>;
}

interface FirebaseAuthVerifier {
  verifyIdToken(token: string): Promise<any>;
}

type GetFirebaseAuth = () => FirebaseAuthVerifier | null;
type Middleware = (req: AuthenticatedRequest, res: Response, next: NextFunction) => void | Promise<void>;

const unauthorized = (res: Response) =>
  res.status(401).json({ success: false, error: 'Autentikasi diperlukan atau sesi tidak valid.' });

const forbidden = (res: Response) =>
  res.status(403).json({ success: false, error: 'Akses ditolak untuk peran ini.' });

export type TransactionReadScope =
  | { ok: true; memberId: string }
  | { ok: false; status: 400 | 403; error: string };

export function resolveTransactionReadScope(
  user: Record<string, any> | undefined,
  requestedMemberId: unknown
): TransactionReadScope {
  if (!user) {
    return { ok: false, status: 403, error: 'Akses ditolak untuk peran ini.' };
  }

  if (user.role === 'CUSTOMER') {
    const memberId = typeof user.memberId === 'string' ? user.memberId.trim() : '';
    if (!memberId) {
      return { ok: false, status: 403, error: 'Sesi member tidak memiliki identitas member yang valid.' };
    }
    // Ignore any memberId supplied by a customer in query params.
    return { ok: true, memberId };
  }

  if (user.role === 'CASHIER' || user.role === 'HO_ADMIN') {
    const memberId = typeof requestedMemberId === 'string' ? requestedMemberId.trim() : '';
    if (!memberId) {
      return { ok: false, status: 400, error: 'ID member wajib disertakan.' };
    }
    return { ok: true, memberId };
  }

  return { ok: false, status: 403, error: 'Akses ditolak untuk peran ini.' };
}

export function canUploadToFolder(
  user: Record<string, any> | undefined,
  folderValue: unknown,
  entityIdValue: unknown
): boolean {
  if (!user) return false;

  const folder = typeof folderValue === 'string' ? folderValue.trim().toLowerCase() : '';
  const entityId = typeof entityIdValue === 'string' ? entityIdValue.trim() : '';
  const role = user.role;

  if (role === 'HO_ADMIN') {
    return ['stores', 'campaigns', 'vouchers'].includes(folder) || (folder === 'members' && Boolean(entityId));
  }
  if (role === 'CASHIER') {
    return folder === 'members' && Boolean(entityId);
  }
  if (role === 'CUSTOMER') {
    return folder === 'members' && Boolean(entityId) && user.memberId === entityId;
  }
  return false;
}

/**
 * Creates fail-closed auth middleware around an injected Firebase Admin verifier.
 * Injection keeps authorization behavior testable without a live Firebase project.
 */
export function createAuthMiddleware(getFirebaseAuth: GetFirebaseAuth) {
  const verifyFirebaseToken: Middleware = async (req, res, next) => {
    const authorization = req.headers.authorization;
    const bearerMatch = typeof authorization === 'string'
      ? /^Bearer\s+([^\s]+)$/i.exec(authorization.trim())
      : null;

    if (!bearerMatch) {
      unauthorized(res);
      return;
    }

    let firebaseAuth: FirebaseAuthVerifier | null = null;
    try {
      firebaseAuth = getFirebaseAuth();
    } catch {
      firebaseAuth = null;
    }

    if (!firebaseAuth) {
      res.status(503).json({
        success: false,
        error: 'Layanan autentikasi belum tersedia. Silakan coba kembali.'
      });
      return;
    }

    try {
      const decoded = await firebaseAuth.verifyIdToken(bearerMatch[1]);
      if (!decoded || typeof decoded.uid !== 'string' || !decoded.uid) {
        unauthorized(res);
        return;
      }
      req.user = decoded as Record<string, any>;
      next();
    } catch {
      // Do not reveal verifier details and never create a fallback identity.
      unauthorized(res);
    }
  };

  const requireHoAdmin: Middleware = (req, res, next) => {
    if (!req.user) {
      unauthorized(res);
      return;
    }
    if (req.user.role !== 'HO_ADMIN') {
      forbidden(res);
      return;
    }
    next();
  };

  const requireCashier: Middleware = (req, res, next) => {
    if (!req.user) {
      unauthorized(res);
      return;
    }
    if (req.user.role !== 'CASHIER' && req.user.role !== 'HO_ADMIN') {
      forbidden(res);
      return;
    }
    next();
  };

  const requireMember: Middleware = (req, res, next) => {
    if (!req.user) {
      unauthorized(res);
      return;
    }
    if (req.user.role !== 'CUSTOMER' || typeof req.user.memberId !== 'string' || !req.user.memberId) {
      forbidden(res);
      return;
    }
    next();
  };

  return { verifyFirebaseToken, requireHoAdmin, requireCashier, requireMember };
}
