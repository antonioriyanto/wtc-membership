import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const server = await readFile(new URL('../server.ts', import.meta.url), 'utf8');
const auth = await readFile(new URL('../server/auth.ts', import.meta.url), 'utf8');
const login = await readFile(new URL('../src/components/LoginWall.tsx', import.meta.url), 'utf8');
const imageStorage = await readFile(new URL('../src/lib/imageStorage.ts', import.meta.url), 'utf8');
const voucherModal = await readFile(new URL('../src/components/CreateVoucherModal.tsx', import.meta.url), 'utf8');

assert.match(server, /createAuthMiddleware\(\(\) => adminAuth\)/);
assert.doesNotMatch(server, /uid:\s*['"]DEFAULT_USER['"],\s*role:\s*['"]HO_ADMIN['"]/);
assert.doesNotMatch(server, /uid:\s*['"]SESSION_USER['"],\s*role:\s*['"]HO_ADMIN['"]/);
assert.doesNotMatch(server, /pin\.toLowerCase\(\)\s*===\s*['"]wtc26['"]/i);
assert.doesNotMatch(server, /firebaseAuth\s*:/);
assert.match(server, /app\.post\(['"]\/api\/loyalty\/add-points['"],\s*verifyFirebaseToken,\s*requireCashier/);
assert.match(server, /app\.post\(['"]\/api\/upload['"],\s*verifyFirebaseToken/);
assert.match(server, /canUploadToFolder\(req\.user,\s*folder,\s*entityId\)/);
assert.match(server, /resolveTransactionReadScope\(req\.user,\s*req\.query\.memberId\)/);
assert.match(server, /\.filter\(t\s*=>\s*t\s*&&\s*t\.memberId\s*===\s*verifiedMemberId\)/);
assert.match(server, /if \(t && t\.memberId === verifiedMemberId\)/);
assert.doesNotMatch(login, /signInWithEmailAndPassword|WatchClub2026Secure|cleanPin\s*===\s*['"]WTC26['"]/);
assert.match(login, /await signInWithCustomToken\(auth,\s*result\.token\)/);
assert.match(imageStorage, /Authorization:\s*`Bearer \$\{idToken\}`/);
assert.match(voucherModal, /apiFetch\(['"]\/api\/upload['"]/);

console.log('PASS: fail-closed middleware wiring');
console.log('PASS: universal employee-login fallbacks and static credential response removed');
console.log('PASS: add-points route uses verified token + cashier/HO role guard');
console.log('PASS: upload route uses verified token + destination scope check');
console.log('PASS: member transaction query scope is derived from verified token for customers');
console.log('PASS: member transaction cache fallback remains scoped to the verified member');
console.log('PASS: upload clients attach ID token through authorized paths');
