import assert from 'node:assert/strict';
import test from 'node:test';
import { canUploadToFolder, createAuthMiddleware, resolveTransactionReadScope } from '../server/auth.ts';

function makeHarness(middleware: Function, request: Record<string, any> = {}) {
  const req: any = { headers: {}, ...request };
  let statusCode = 200;
  let responseBody: any;
  let nextCalls = 0;
  const res: any = {
    status(code: number) {
      statusCode = code;
      return this;
    },
    json(body: any) {
      responseBody = body;
      return this;
    }
  };
  const next = () => { nextCalls += 1; };
  return {
    req,
    res,
    next,
    result: async () => await middleware(req, res, next),
    get statusCode() { return statusCode; },
    get responseBody() { return responseBody; },
    get nextCalls() { return nextCalls; }
  };
}

test('missing bearer token is rejected without setting a user', async () => {
  const guards = createAuthMiddleware(() => ({ verifyIdToken: async () => ({ uid: 'unexpected' }) }));
  const h = makeHarness(guards.verifyFirebaseToken);
  await h.result();
  assert.equal(h.statusCode, 401);
  assert.equal(h.nextCalls, 0);
  assert.equal(h.req.user, undefined);
});

test('malformed bearer header is rejected', async () => {
  const guards = createAuthMiddleware(() => ({ verifyIdToken: async () => ({ uid: 'unexpected' }) }));
  const h = makeHarness(guards.verifyFirebaseToken, { headers: { authorization: 'Basic invalid' } });
  await h.result();
  assert.equal(h.statusCode, 401);
  assert.equal(h.nextCalls, 0);
});

test('unavailable Firebase verifier returns 503 instead of bypassing auth', async () => {
  const guards = createAuthMiddleware(() => null);
  const h = makeHarness(guards.verifyFirebaseToken, { headers: { authorization: 'Bearer token' } });
  await h.result();
  assert.equal(h.statusCode, 503);
  assert.equal(h.nextCalls, 0);
  assert.equal(h.req.user, undefined);
});

test('invalid token is rejected without a synthetic privileged identity', async () => {
  const guards = createAuthMiddleware(() => ({ verifyIdToken: async () => { throw new Error('invalid'); } }));
  const h = makeHarness(guards.verifyFirebaseToken, { headers: { authorization: 'Bearer invalid-token' } });
  await h.result();
  assert.equal(h.statusCode, 401);
  assert.equal(h.nextCalls, 0);
  assert.equal(h.req.user, undefined);
});

test('verified token attaches the verified claims and continues', async () => {
  const decoded = { uid: 'staff-1', role: 'CASHIER', storeId: 'PIM' };
  const guards = createAuthMiddleware(() => ({ verifyIdToken: async () => decoded }));
  const h = makeHarness(guards.verifyFirebaseToken, { headers: { authorization: 'Bearer valid-token' } });
  await h.result();
  assert.equal(h.statusCode, 200);
  assert.equal(h.nextCalls, 1);
  assert.deepEqual(h.req.user, decoded);
});

test('HO guard returns 403 for cashier and continues for HO_ADMIN', () => {
  const guards = createAuthMiddleware(() => null);
  const denied = makeHarness(guards.requireHoAdmin, { user: { uid: 'cashier-1', role: 'CASHIER' } });
  guards.requireHoAdmin(denied.req, denied.res, denied.next);
  assert.equal(denied.statusCode, 403);
  assert.equal(denied.nextCalls, 0);

  const accepted = makeHarness(guards.requireHoAdmin, { user: { uid: 'admin-1', role: 'HO_ADMIN' } });
  guards.requireHoAdmin(accepted.req, accepted.res, accepted.next);
  assert.equal(accepted.nextCalls, 1);
});

test('cashier guard accepts cashier/HO and rejects member', () => {
  const guards = createAuthMiddleware(() => null);
  for (const role of ['CASHIER', 'HO_ADMIN']) {
    const h = makeHarness(guards.requireCashier, { user: { uid: role, role } });
    guards.requireCashier(h.req, h.res, h.next);
    assert.equal(h.nextCalls, 1, `${role} should pass`);
  }
  const denied = makeHarness(guards.requireCashier, { user: { uid: 'member-1', role: 'CUSTOMER', memberId: 'M1' } });
  guards.requireCashier(denied.req, denied.res, denied.next);
  assert.equal(denied.statusCode, 403);
  assert.equal(denied.nextCalls, 0);
});

test('member guard requires CUSTOMER role and a memberId claim', () => {
  const guards = createAuthMiddleware(() => null);
  const accepted = makeHarness(guards.requireMember, { user: { uid: 'member-1', role: 'CUSTOMER', memberId: 'M1' } });
  guards.requireMember(accepted.req, accepted.res, accepted.next);
  assert.equal(accepted.nextCalls, 1);

  const denied = makeHarness(guards.requireMember, { user: { uid: 'staff-1', role: 'CASHIER' } });
  guards.requireMember(denied.req, denied.res, denied.next);
  assert.equal(denied.statusCode, 403);
  assert.equal(denied.nextCalls, 0);
});


test('upload scope limits members to their own member asset folder', () => {
  assert.equal(canUploadToFolder({ uid: 'm1', role: 'CUSTOMER', memberId: 'M1' }, 'members', 'M1'), true);
  assert.equal(canUploadToFolder({ uid: 'm1', role: 'CUSTOMER', memberId: 'M1' }, 'members', 'M2'), false);
  assert.equal(canUploadToFolder({ uid: 'm1', role: 'CUSTOMER', memberId: 'M1' }, 'vouchers', ''), false);
});

test('upload scope reserves administrative assets for HO admins', () => {
  for (const folder of ['stores', 'campaigns', 'vouchers']) {
    assert.equal(canUploadToFolder({ uid: 'ho', role: 'HO_ADMIN' }, folder, ''), true);
    assert.equal(canUploadToFolder({ uid: 'cashier', role: 'CASHIER' }, folder, ''), false);
  }
  assert.equal(canUploadToFolder({ uid: 'cashier', role: 'CASHIER' }, 'members', 'M1'), true);
  assert.equal(canUploadToFolder({ uid: 'guest', role: 'UNKNOWN' }, 'members', 'M1'), false);
  assert.equal(canUploadToFolder(undefined, 'vouchers', ''), false);
});


test('customer transaction scope ignores a caller-supplied memberId', () => {
  assert.deepEqual(
    resolveTransactionReadScope({ uid: 'auth-1', role: 'CUSTOMER', memberId: 'MEMBER-OWN' }, 'MEMBER-OTHER'),
    { ok: true, memberId: 'MEMBER-OWN' }
  );
});

test('staff transaction scope requires an explicit memberId and rejects unknown roles', () => {
  assert.deepEqual(
    resolveTransactionReadScope({ uid: 'cashier-1', role: 'CASHIER' }, ' MEMBER-1 '),
    { ok: true, memberId: 'MEMBER-1' }
  );
  assert.equal(resolveTransactionReadScope({ uid: 'cashier-1', role: 'CASHIER' }, '').ok, false);
  assert.equal(resolveTransactionReadScope({ uid: 'guest-1', role: 'UNKNOWN' }, 'MEMBER-1').ok, false);
});
