# Implementation Log — Watch Club Membership

- **Tanggal:** 2026-10-13
- **Workspace:** extracted local ZIP at `wtc-membership-main/`; no Git remote configured.
- **Production/deployment changes:** none.
- **Dependency installation:** none.
- **Data migration:** none.

## Batch A — Trusted authentication boundary (partial containment)

**Status:** Source changes implemented locally; acceptance criteria are only partially verified because the full application and Firebase services were not started. This batch does **not** make the whole repository production-safe.

### Findings addressed

- **F-001 — CONFIRMED, remediated in working copy:** fail-open auth middleware was replaced by a fail-closed implementation. No bearer token or malformed token returns 401; missing verifier returns 503; token verification failure returns 401; role mismatch returns 403 without calling `next()`.
- **F-004 — CONFIRMED, partially remediated in working copy:** server-side universal fallback PIN paths and static `firebaseAuth` credential response were removed. Employee login now requires Firebase Admin auth and a successfully minted custom token. Frontend no longer attempts fixed email/password credentials or local PIN-only fallback when API fails. Real deployed credential rotation remains unverified and must happen separately if any removed credential was ever used in a real environment.
- **F-006 — CONFIRMED, partially remediated:** `/api/loyalty/add-points` now requires a verified ID token and CASHIER/HO_ADMIN role. Server still needs stronger sales evidence validation, cashier/store-scope enforcement across the complete domain, and atomic idempotency work in Batch E.
- **F-010 — CONFIRMED, partially remediated:** `/api/upload` now requires a verified ID token and checks role/folder/entity scope. `src/lib/imageStorage.ts` attaches Firebase ID token where a current user exists; `CreateVoucherModal.tsx` uses `apiFetch`. Magic-byte validation, per-user/IP rate limit, storage quota, base64 size controls, and earlier scope-check-before-buffer parsing remain unresolved. The current policy lets CASHIER upload into any non-empty member entity ID and does not check that member against the cashier's store; whether that capability is required must be settled before tightening it. The server upload route still parses the multipart body before the final folder/entity authorization check, though authentication runs first.
- **F-022 — CONFIRMED, remediated in working copy:** `/v1/member/transactions` now resolves customer scope from the verified token, ignores memberId query overrides for a customer, and filters cache fallback results by the resolved member ID including the catch fallback. Runtime endpoint integration remains unverified.

### Files changed

| File | Change | Reason |
|---|---|---|
| `server/auth.ts` (new) | Extracted testable middleware and helpers for fail-closed token validation, role checks, transaction read scope and upload scope. | Reduce auth bypass risk and make guard behavior unit-testable without real Firebase. |
| `server.ts` | Rewired auth/role middleware; removed employee login universal PIN fallback and static Firebase credential response; requires custom-token issuance; adds authentication/folder scope to upload; protects add-points; constrains member transaction reads and error fallback. | Address the specific confirmed auth/scope defects. |
| `src/components/LoginWall.tsx` | Removed fixed email/password fallback and local PIN fallback; requires expected role, returned custom token and successful Firebase sign-in before calling login callback; uses server-returned store scope. | Prevent UI-only login bypass and align client with server-authenticated identity. |
| `src/lib/imageStorage.ts` | Adds Firebase ID token to server upload request when an authenticated user is available. | Keep legitimate uploads compatible with the newly protected endpoint. |
| `src/components/CreateVoucherModal.tsx` | Uses shared `apiFetch` for upload request so the Firebase token is added. | Keep voucher-image upload caller aligned with endpoint authentication. |
| `package.json` | Adds `test:auth` and `test:remediation` commands using Node built-in test/runtime features. | Enable focused tests without installing a new testing framework. |
| `scripts/test-auth-middleware.ts` (new) | 12 unit tests for missing/invalid token, unavailable verifier, role guards, upload scope, and transaction read scope. | Verifies the extracted auth policy without production credentials. |
| `scripts/check-remediation-source.mjs` (new) | Static assertions for guard wiring, fallback removal, scoped transaction fallback, and caller token propagation. | Lightweight regression check while Vitest/Express dependencies are unavailable. |

### Commands executed and actual outcomes

| Command | Outcome | Notes |
|---|---|---|
| `npm run test:auth` | **PASS** | 12 tests passed, 0 failed. Node prints an experimental warning for `--experimental-strip-types`. |
| `npm run test:remediation` | **PASS** | All 7 printed assertion groups passed (each group includes one or more source assertions). |
| `node --experimental-strip-types --check server.ts` | **PASS** | Syntax/parser check only; not a full Express runtime check. |
| `node --experimental-strip-types --check server/auth.ts` | **PASS** | Syntax/parser check only. |
| `tsc --noEmit --strict --skipLibCheck --target ES2022 --module ESNext --moduleResolution bundler /tmp/wtc-express-shim.d.ts server/auth.ts` | **PASS (limited)** | Isolated strict type-check using a temporary minimal Express type shim outside the project; does not validate all project files or real Express typings. |
| `git diff --check` | **PASS** | No whitespace errors. |
| `npm test` | **BLOCKED** | `vitest` executable is not installed (`node_modules` absent). |
| `npm run lint` | **BLOCKED** | TypeScript cannot resolve application modules/types such as Express, React, Firebase, Vite, and Node types because dependencies are not installed. |
| `npm run build` | **BLOCKED** | `vite` executable is not installed. |

### Known limitations / unresolved work

- Firestore Rules still contain confirmed permissive rules (F-002); this is a **P0 unresolved** issue.
- Many sensitive REST CRUD routes still lack authorization (F-003); this is a **P0 unresolved** issue.
- PIN recovery/account linking (F-005 and F-023), transaction immutability (F-007), atomic receipt uniqueness (F-008), unknown-member fallback (F-009), durability (F-011), and write acknowledgement semantics (F-012) remain unresolved.
- `/api/members/link-google` legacy alias still has no middleware and the common handler has identity-proof concerns (F-023). It is intentionally not changed in this batch because the supported client flow currently switches provider identity and needs a coherent, tested account-link design; a blind guard could lock out legitimate members without solving identity binding.
- No end-to-end login, add-points or upload request was run against Express/Firebase. No active Firestore rules were queried. No UI/browser/physical device or printer test was possible.
- The full application must **not** be considered safe for production based on this batch.

### Regression assessment

No regressions were observed in the focused middleware tests or static source checks. Broad UI/API regressions cannot be ruled out because the full build, existing Vitest suite and runtime integrations were blocked. Upload may take its pre-existing Firebase Storage/DataURL fallback when the server rejects a request; this behavior should be reviewed in a later batch so failed upload state is explicit rather than silently stored as inline data.

### Rollback

This is a local working copy; no remote or production target was changed. The code baseline is local commit `2126e94`. To roll back only Batch A tracked-source changes, inspect the diff first and restore `package.json`, `server.ts`, `src/components/LoginWall.tsx`, `src/lib/imageStorage.ts`, and `src/components/CreateVoucherModal.tsx` from that local baseline; remove the newly added `server/auth.ts`, `scripts/test-auth-middleware.ts`, and `scripts/check-remediation-source.mjs` if fully rolling back. Keep the audit/plan/report documents. **Do not deploy the baseline as a security rollback without a separate incident decision**, because it restores the known bypasses.
