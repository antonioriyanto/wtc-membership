# Final Regression Report — Watch Club Membership

- **Date:** 2026-10-13
- **Scope:** Batch A local remediation only.
- **Runtime/production:** Application server and production services were not started or contacted.
- **Status vocabulary:** PASS, FAIL, BLOCKED, NOT RUN.

| Test | Expected result | Actual result | Status | Evidence |
|---|---|---|---|---|
| Focused auth middleware tests — `npm run test:auth` | Missing/invalid tokens rejected; valid token attaches verified claims; role and scope checks enforce policy. | 12 tests passed, 0 failed. | **PASS** | Node test output: `# tests 12`, `# pass 12`, `# fail 0`. |
| Static remediation assertions — `npm run test:remediation` | New fail-closed wiring is present; prohibited fallbacks removed; upload callers pass tokens; transaction fallback is scoped. | All 7 printed check groups passed. These are source assertions, not runtime/API tests. | **PASS** | Command printed seven `PASS:` groups and exited 0. |
| `node --experimental-strip-types --check server.ts` | Backend source parses. | Exit code 0. | **PASS** | Node syntax check. Does not resolve imports or start Express. |
| `node --experimental-strip-types --check server/auth.ts` | Extracted middleware source parses. | Exit code 0. | **PASS** | Node syntax check. |
| Isolated strict check of `server/auth.ts` with temporary Express shim | Extracted policy helper type-checks under strict TypeScript. | Exit code 0 using `/tmp/wtc-express-shim.d.ts`. Real Express package typings were unavailable. | **PASS** | Command: `tsc --noEmit --strict --skipLibCheck --target ES2022 --module ESNext --moduleResolution bundler /tmp/wtc-express-shim.d.ts server/auth.ts`. Limited result only. |
| `git diff --check` | No whitespace errors in tracked diffs. | Exit code 0. | **PASS** | Git diff check. |
| Existing test suite — `npm test` | Existing Vitest unit tests execute and report results. | Shell could not find `vitest` (`node_modules` absent). | **BLOCKED** | Exit code 127; `vitest: not found`. |
| Full TypeScript/lint script — `npm run lint` | Complete project typecheck exits without errors. | TypeScript invocation ran but emitted unresolved-module/type errors for missing React, Firebase, Express, Vite, Node types and other packages. | **BLOCKED** | Exit code 2; dependency tree not installed, so this is not a valid complete code verdict. |
| Production frontend/backend build — `npm run build` | Vite and esbuild build the application. | Build stopped because `vite` executable was not found. | **BLOCKED** | Exit code 127; `vite: not found`. |
| Employee login end-to-end with real Firebase custom token | Valid PIN creates a token; client exchange succeeds; invalid/fallback PIN is rejected. | Not run because Express/Firebase dependencies and test project credentials/emulator were not available. | **BLOCKED** | Only pure middleware tests and static assertions ran. |
| Add-points HTTP integration (anonymous/member/cashier/HO roles) | Invalid/unauthenticated requests rejected; approved staff flow works. | Not run against Express/Firebase. | **BLOCKED** | Guard wiring static assertion passed; no live route integration. |
| Upload HTTP integration (folder scope, multipart/base64 abuse, member ownership) | Only authenticated, permitted roles write valid content within limits. | Not run. Signature validation, quota/rate controls and base64 limits remain unresolved. | **BLOCKED** | Unit-tested folder policy; no HTTP parser or storage integration. |
| Firebase Rules emulator matrix | Anonymous/member/cashier/HO access follows intended allowlist. | Not run; emulator test harness/config and dependencies were unavailable. Existing open rules are still unresolved. | **BLOCKED** | See `VALIDATION_REPORT.md`, F-002. |
| Firestore duplicate-receipt concurrency / ledger mutation tests | Duplicate receipt creates at most one earning; transaction history is append-only. | Not run; Batch E is unimplemented. | **NOT RUN** | Requires a domain/test harness and concurrency-capable emulator. |
| Restart/multi-instance persistence tests | Completed data survives restart and state converges across instances. | Not run; Batch F is unimplemented and Docker runtime was not built. | **NOT RUN** | Requires Docker/deployment-like environment and a defined persistence contract. |
| Browser visual/responsive/keyboard audit | Critical workflows and accessible controls remain usable at supported viewports. | Not run; browser runtime/screenshots unavailable. | **NOT RUN** | UI changes in Batch A are limited to login behavior; no visual claims made. |
| Production API, Firestore rules or deployment inspection | Verify current live deployment and active security posture. | Intentionally not run. | **NOT RUN** | No production service was contacted and no deploy occurred. |

## Acceptance summary

- **Passed:** focused auth unit tests; static remediation checks; TypeScript syntax checks; isolated strict type-check of the extracted auth module using a test shim; diff whitespace check.
- **Blocked:** baseline app test/build/full type-check and HTTP/Firebase integration checks, due missing installed dependencies and unavailable isolated test services.
- **Not run:** UI/device, production, concurrency, and persistence regression scenarios.

No test was marked PASS based solely on source edits. Batch A is a **partial local remediation**, not proof that the entire application is fixed or production-ready.
