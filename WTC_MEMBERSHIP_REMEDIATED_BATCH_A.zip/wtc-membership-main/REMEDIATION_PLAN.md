# Remediation Plan — Watch Club Membership

- **Prepared:** 2026-10-13, after static validation in `VALIDATION_REPORT.md` and before source changes.
- **Scope:** Incremental changes to the supplied ZIP. No production/deployment operations are authorized. The initial environment has no `node_modules` and no Git metadata.
- **Baseline checkpoint:** local-only Git commit `2126e94` created from the extracted archive; no remote is configured.

## Batch overview

| Batch | Priority | Findings | Goal | Effort | Status |
|---|---|---|---|---|---|
| A — Trusted auth boundary for employee login, points and uploads | P0/P1 | F-001, F-004, F-006, F-010 (partial), F-022 | Fail closed in shared auth guards; remove fallback credentials/login bypass; guard high-risk writes; authenticate legitimate upload callers and constrain upload scope; enforce member transaction read scope. | Medium | Implemented locally; full integration/build verification blocked |
| B — REST route authorization and data minimization | P0 | F-003 (plus residual F-002/F-006/F-010) | Route/access matrix; per-role/store/member ownership; input DTO allowlists; protect all REST CRUD/read endpoints and remove sensitive public output. | Large | Planned; requires caller inventory/migration |
| C — Firestore and Storage rules hardening | P0 | F-002, residual F-010 | Replace unconditional permissions with explicit least-privilege rules; migrate any required direct-client writes first; run Firebase Emulator rule matrix. | Large | Planned; blocked until direct-client operation map and emulator setup |
| D — PIN recovery and account identity proof | P1 | F-005 | Bind recovery to verified Firebase ID token or OTP; prevent phone-only PIN takeover; add throttling/replay and recovery audit. | Medium/Large | Planned; recovery UX decision needed |
| E — Loyalty earning, ledger immutability and receipt idempotency | P1 | F-007, F-008, F-009 | Append-only transaction ledger; atomic canonical receipt reservation; no synthetic member on offline fallback; reversal contract. | Large | Planned; depends on API scope + transaction schema/tests |
| F — Persistence/write acknowledgement and container deployment | P1 | F-011, F-012 | Make response semantics honest; use durable source/outbox; remove false success on failed remote writes; prove restart/multi-instance recovery. | Large | Planned; data-store decision needed |
| G — PWA, accessibility and task-based UI usability | P2 | F-013, F-014, F-015 | Stabilize service-worker lifecycle; clear per-user caches; keyboard/focus/lang improvements; test target viewports without redesigning brand. | Medium | Planned after critical boundaries |
| H — Dependency, test coverage and maintainability | P2/INFO | F-016–F-021 | Patch affected dependency versions after compatibility checks; add CI/SCA; curate patch scripts; refactor only behind tests. | Medium/Large | Planned |

## Batch A — Trusted auth boundary for employee login, points and uploads

### Findings / root cause

- **F-001:** middleware contains demo fallbacks that assign privileged role on missing/invalid credentials; role guards do not reject mismatch.
- **F-004:** server accepts universal fallback PINs and returns fixed Firebase credentials; frontend has its own bypass when API is unavailable and does not require Firebase sign-in to succeed before invoking the local login callback.
- **F-006:** point-earning endpoint is unguarded.
- **F-010 (partial):** upload handler is unguarded and uses Admin SDK; legitimate callers send no ID token.

### Files expected to change

- `server/auth.ts` (new, isolated injectable middleware)
- `scripts/test-auth-middleware.ts` (new, Node built-in test suite to avoid adding dependencies)
- `scripts/check-remediation-source.mjs` (new static remediation assertions)
- `server.ts`
- `src/components/LoginWall.tsx`
- `src/lib/imageStorage.ts`
- `src/components/CreateVoucherModal.tsx`
- `package.json` (add an explicit auth-test command without replacing the existing test suite)
- `IMPLEMENTATION_LOG.md` and `FINAL_REGRESSION_REPORT.md`

### Proposed solution

1. Verify `Authorization: Bearer <ID token>` with Firebase Admin; missing token returns 401, unavailable verification service returns 503, and invalid/expired token returns 401. Never synthesize a user.
2. Make role guards fail closed with 401/403, and test the guard behavior with injected mock auth provider.
3. Remove server PIN fallbacks and fixed email/password response. Return failure when custom-token minting is unavailable/failed.
4. The login client must successfully exchange a custom token before calling its login callback. Remove PIN-based local auth fallback and email/password fallback credentials.
5. Require a verified token on `/api/loyalty/add-points`; caller already uses `apiFetch`, which attaches the Firebase ID token. `requireCashier` also permits the established HO admin role.
6. Require a verified token on `/api/upload`; verify allowed folder/scope after multipart parsing. `members/<id>` is allowed only for that member or an authorized staff role; store/campaign/voucher assets are restricted to HO. Update existing upload clients to attach their current Firebase ID token.
7. Run Node built-in tests against the injectable middleware, syntax/static checks, `git diff --check`, and route/client source assertions. Full app build/Vitest remain blocked unless dependencies become available.

### Dependencies and regression risk

- Employee login will intentionally stop working when Firebase Admin cannot mint a custom token; offline/local mock login is not a safe substitute for server-authenticated identity.
- Existing stores/campaigns/vouchers/member-image uploads must send a valid ID token and match folder scope. Validate each call site.
- Some older clients may depend on the `firebaseAuth` response. Search confirmed one caller; remove it in the same batch.
- This batch does **not** fix unguarded member/store/transaction/support/audit CRUD routes nor Firestore direct client rules. Do not describe the whole application as secure after Batch A.

### Acceptance criteria

- No missing/invalid token gets `req.user`.
- Missing Firebase Admin verifier prevents protected requests rather than bypassing them.
- Role mismatch returns 403 and does not call `next()`.
- Employee login success is only returned when a custom token was minted; response contains no fixed password.
- If custom-token sign-in fails in the client, `onLoginSuccess` is not called.
- Anonymous add-points/upload requests are rejected before route handler work.
- Upload callers send Firebase ID token, and a member cannot upload into another member's profile folder or administrative folder.
- Focused auth tests and static checks pass; build/Vitest status is recorded honestly.

### Rollback

Revert the Batch A source diff as a unit using Git; retain report/plan/log files. Do not rollback by restoring any fallback PIN or fixed credential. If legitimate callers fail, repair auth token propagation or folder scoping instead of reopening anonymous access.

## Batch B — REST route authorization and data minimization

1. **Root cause:** route-by-route authorization is inconsistent; many callers bypass centralized `apiFetch`; request bodies are merged into records.
2. **Expected files:** `server.ts` (later route modules), `src/lib/apiClient.ts`, `src/lib/syncFirestore.ts`, `src/lib/sync-worker.ts`, callers of members/stores/vouchers/campaigns/transactions/support/audit APIs, route tests.
3. **Plan:** enumerate every REST route and every caller; classify anonymous/precheck, CUSTOMER owner-only, CASHIER store-scoped, and HO global/admin actions. Add middleware/DTO allowlist per action. Update callers to attach ID tokens. Strip PII from public precheck. Separate public minimal lookup from authenticated member directory.
4. **Dependencies:** Batch A auth guards, complete caller mapping, tests.
5. **Regression risks:** offline cache sync and HO/cashier screens currently use plain fetch. Protecting routes before migrating callers can break them; perform route groups one at a time.
6. **Tests/acceptance:** anonymous caller receives 401; member cannot list other members or mutate records; cashier cannot spoof store scope; HO-only actions reject cashier/member; request body cannot mutate protected fields; no unnecessary PII appears in responses.
7. **Effort:** Large. **Rollback:** revert the route group + caller migration together; never revert to globally public CRUD.

## Batch C — Firestore and Storage rules hardening

1. Map all current direct-client Firestore operations first. Migrate critical ledger/config/audit writes to trusted server endpoints where practical.
2. Replace unconditional `true` grants with rules based on verified claims and owner/resource scope; use no direct client mutation for immutable ledger if no use case justifies it.
3. Set up Firebase Emulator Rules Unit Testing using non-production project identifiers only.
4. **Dependencies:** Batch B operation map and test harness. **Risks:** member activity, ticket create/update, dashboards, and direct listeners may stop working if rules tighten before call-site migrations.
5. **Acceptance:** anonymous/member/cashier/HO matrix tests for get/list/create/update/delete on every collection; owner-scope queries prove ownership; no public writes to config/campaign/transaction/audit.
6. **Effort:** Large. **Rollback:** restore prior rule file only to a non-production branch; never deploy old permissive rules as a production rollback without an incident decision.

## Batch D — PIN recovery and identity proof

Addresses **F-005 and F-023**, including the legacy unauthenticated `/api/members/link-google` alias and the current Google-link identity/token-switching ambiguity.

1. Require verified Google ID token or OTP/recovery proof for first setup/reset. Do not trust `googleUid`/email in a body. Tie token subject to existing member record and reject unlinked identities without a second factor.
2. Keep messages privacy-safe to reduce account enumeration; log actor/recovery result without logging PIN/OTP/token.
3. **Dependencies:** product decision about OTP provider and legitimate recovery UX. **Risks:** existing first-time signup flows require another verification step.
4. **Acceptance:** phone-only, fake UID/email, wrong Google account, expired token, replay and rate-limit tests fail safely; valid verified flow works end-to-end.
5. **Effort:** Medium/Large. **Rollback:** revert only through controlled server release; do not re-enable phone-only reset.

## Batch E — Loyalty earning, ledger and duplicate receipt

1. Verify member exists in authoritative store before earning. Never synthesize a member/transaction when a lookup failed.
2. Canonicalize receipt consistently; atomically reserve deterministic receipt key and write transaction/member balance in one transaction. Clarify uniqueness scope using existing INV-003 (global national receipt uniqueness).
3. Prevent overwrite/delete of existing transactions; correct through idempotent reversal/adjustment linked to original transaction.
4. **Dependencies:** Batch B API roles, defined source-of-truth, duplicate-receipt test data/migration review. **Risks:** historical duplicates/receipt format differences; never auto-delete existing financial records.
5. **Acceptance:** parallel cross-instance claims result in at most one earn event; unknown member never creates a record; transaction update/delete endpoint is rejected; reversal adds new entry only; tier/multiplier invariants remain intact.
6. **Effort:** Large. **Rollback:** feature-flag new earning writer where possible; keep append-only audit and reconcile before any retry/replay. Do not restore edit/delete paths.

## Batch F — Persistence and deployment reliability

1. Define `committed`, `queued`, or `failed` semantics for remote writes and a durable offline outbox/queue. LocalStorage/ephemeral container files must not be described as durable primary persistence.
2. Update Docker only after the data storage decision; read-only seed content can be copied explicitly, but mutable source-of-truth belongs in durable shared storage.
3. **Dependencies:** source-of-truth decision, idempotency from Batch E. **Risks:** delayed confirmation and explicit pending state may alter cashier UX.
4. **Acceptance:** Firestore failure cannot return false success; restart/retry does not duplicate effects; two instances converge; completed transactions survive restart.
5. **Effort:** Large. **Rollback:** retain old deployment artifact and use controlled rollout; do not run destructive migrations or deploy during this work without approval.

## Batch G — PWA, accessibility and usability

- Remove global service-worker unregister logic or replace it with a versioned, one-time migration after testing.
- Clear/scope sensitive local cache during logout/account switch without destroying the offline outbox.
- Set `lang="id"`, unify focus visibility, labels, error/disabled states, and keyboard modal behavior.
- Test task flows on target tablet/mobile viewport and keyboard-open states before visual redesign; preserve Watch Club identity.
- **Dependencies:** security boundary + testable build. **Effort:** Medium. **Acceptance:** no keyboard trap/hidden focus; relevant operations visible at agreed viewports; service worker survives reload/update/offline tests. **Rollback:** revert individual UI changes; do not restore cache behaviors that expose cross-user data.

## Batch H — Dependency, coverage and technical debt

- Upgrade Vite to an affected-advisory-free compatible version; investigate a supported patched SheetJS source/version. Verify actual XLSX use remains export-only.
- Add CI typecheck/unit/integration/build/SCA from a clean checkout. Curate top-level patch/wipe scripts with dry-run/environment guards before deletion or relocation.
- Extract route groups/components incrementally only after tests exist; do not perform a total rewrite.
- **Dependencies:** critical remediation tests and dependency compatibility checks. **Effort:** Medium/Large. **Acceptance:** reproducible clean CI and no unreviewed script executes in deployment pipeline. **Rollback:** isolate upgrades/refactors in independent commits.

## Implementation order

1. Batch A (this implementation).
2. Batch B route/caller matrix; protect one domain at a time (members, stores/promotions, support/audit, transactions).
3. Batch C rules after all relevant direct-client callers have been migrated or accounted for.
4. Batch D and E in coordination, because member identity, point writes and transaction events share trust boundaries.
5. Batch F after idempotency and durable outbox semantics are agreed.
6. Batch G and H; small dependency patch can run in parallel with API work but must have independent build/export verification.

No batch is considered complete solely because source was edited. Completion requires acceptance criteria and recorded evidence in `IMPLEMENTATION_LOG.md` and `FINAL_REGRESSION_REPORT.md`.


## Batch A implementation record

Batch A code changes are present in the current working copy. `npm run test:auth` passes 12/12 focused unit tests; `npm run test:remediation` passes static source assertions; `node --experimental-strip-types --check server.ts` and `git diff --check` pass. The full `npm test`, `npm run lint`, and `npm run build` remain blocked by absent dependencies (`vitest`, Vite, React/Firebase/Express types). See `IMPLEMENTATION_LOG.md` and `FINAL_REGRESSION_REPORT.md` for actual command outcomes.
