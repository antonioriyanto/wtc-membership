import React from 'react';
import { 
  LayoutDashboard, 
  Award, 
  Ticket, 
  Users, 
  ExternalLink,
  ChevronRight,
  ClipboardList,
  Megaphone,
  MessageSquare,
  Store,
  Receipt,
  LogOut
} from 'lucide-react';
import { TabType } from '../types';
import { WatchClubLogo } from './WatchClubLogo';

interface SidebarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  storesCount: number;
  membersCount: number;
  vouchersCount: number;
  transactionsCount?: number;
  onOpenQuickLauncher: () => void;
  onLogout?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  storesCount,
  membersCount,
  vouchersCount,
  transactionsCount,
  onOpenQuickLauncher,
  onLogout
}) => {
  const navItems: { id: TabType; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string | number }[] = [
    { id: 'overview', label: 'Ringkasan Dasbor', icon: LayoutDashboard },
    { id: 'transactions', label: 'Transaksi Nasional', icon: Receipt, badge: transactionsCount },
    { id: 'stores', label: 'Pengaturan Toko & Cabang', icon: Store, badge: storesCount },
    { id: 'members', label: 'Data Pelanggan', icon: Users, badge: membersCount },
    { id: 'loyalty', label: 'Pengaturan Level Tier', icon: Award },
    { id: 'vouchers', label: 'Voucher & Promo', icon: Ticket, badge: vouchersCount },
    { id: 'campaigns', label: 'Pesan & Promo', icon: Megaphone },
    { id: 'support', label: 'Tiket Bantuan', icon: MessageSquare },
    { id: 'audit', label: 'Riwayat Sistem (Audit)', icon: ClipboardList }
  ];

  return (
    <aside className="w-72 bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-white flex flex-col h-screen sticky top-0 shrink-0 border-r border-slate-200 dark:border-slate-800 shadow-2xl z-30 transition-colors">
      <div className="p-6 border-b border-slate-200 dark:border-slate-800/80">
        <div className="flex items-center justify-between gap-3 mb-3">
          <WatchClubLogo className="w-36" />
          <span className="px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 rounded-md">
            HO PIK
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 dark:bg-emerald-400 animate-pulse"></div>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium tracking-wide">
            Sinkronisasi Cloud • Online
          </span>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5 custom-scrollbar">
        <div className="px-3 pb-2 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
          Modul Manajemen
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all duration-200 group text-left ${
                isActive
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold shadow-sm dark:shadow-inner border border-slate-200 dark:border-slate-700/60'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200 dark:hover:bg-slate-800/50 hover:translate-x-1'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`p-1.5 rounded-lg transition-colors ${
                  isActive ? 'bg-slate-100 dark:bg-slate-700 text-emerald-600 dark:text-emerald-400' : 'text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200'
                }`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span className={`px-2 py-0.5 text-xs rounded-full font-semibold ${
                  isActive ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/30' : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
        <div className="pt-6 px-3 pb-2 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
          Pintasan & Pindah Portal
        </div>
        <button
          onClick={onOpenQuickLauncher}
          className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm text-amber-300 bg-amber-950/30 hover:bg-amber-900/40 border border-amber-500/30 transition-all text-left group"
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
              <ExternalLink className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-amber-200">Pengalih Peran Sistem</div>
              <div className="text-[10px] text-amber-400/80">Kasir Toko / Member Web</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-amber-400 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-bold flex items-center justify-center text-sm shadow-md shrink-0">
              HO
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">Head Office</div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">HO PIK Admin</div>
            </div>
          </div>
          {onLogout && (
            <button
              onClick={onLogout}
              title="Logout HO Admin"
              className="p-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-500/30 transition-all flex items-center justify-center shrink-0 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </aside>
  );
};
